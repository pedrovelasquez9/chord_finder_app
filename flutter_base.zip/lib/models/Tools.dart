class Tools {
  String name;

  Tools({String name}) {
    this.name = name;
  }
}
