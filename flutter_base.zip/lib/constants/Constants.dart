class Constants {
  static const Map CONSTANTS = {"api_base_url": "https://jsonplaceholder.typicode.com/posts/1"};

  Map getConstants() {
    return CONSTANTS;
  }
}
